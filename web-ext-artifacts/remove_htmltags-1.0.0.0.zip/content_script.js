// Put all the javascript code here, that you want to execute after page load.

document.querySelectorAll("a[href^='https://c.lazada.vn']").forEach((elem) => {
  elem.parentElement.setAttribute("hidden", "");
});

document.querySelectorAll("a[href^='https://tags.native-ad.net']").forEach((elem) => {
  elem.parentElement.setAttribute("hidden", "");
});
