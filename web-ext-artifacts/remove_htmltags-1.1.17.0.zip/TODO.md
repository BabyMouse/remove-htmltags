# TODO
- Created: 2022.12.16
- Updated: 2022.12.20

## MV2 -> MV3 (*Firefox will support after 17.1.2023*)
### File `manifest.json`
- [ ] Change: `browser_action` -> `action`
- [ ] Delete: `background\persistent: false`
