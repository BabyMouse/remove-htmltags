# TODO
- Created: 2022.12.16
- Updated: 2022.12.16

### MV2 -> MV3
- ` "browser_action" -> "action" `
