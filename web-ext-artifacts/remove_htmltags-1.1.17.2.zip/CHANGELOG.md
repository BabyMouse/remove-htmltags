# Changelog
- Created: 2022.12.15
- Updated: 2023.01.06

All notable changes to this project will be documented in this file.

## [1.1.x.x]
### Added
- 

### Changed
- 

## [1.1.17.0] - 2023.01.06
### Added
- Localize.

## [1.1.15] - 2022.12.30
### Added
- [Notification system] Added `Popup` type.
- Select to turn on/ off the notification.

## [1.1.14] - 2022.12.22
### Added
- [`Options`] added `timeout` (run the script after delay some seconds).
- [`Action`] added `view-source` (for Tab activated).
- `Notify` "The script has been completed".

## [1.0.0] - 2022.12.13
### Created
- Start up this project.
- Submit to AMO.

### Bugs
- Don't run on Firefox for Android.