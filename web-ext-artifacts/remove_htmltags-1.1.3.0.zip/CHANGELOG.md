# Changelog
All notable changes to this project will be documented in this file.

## [1.1.0]
### Added
- 

### Changed
- 

## [1.0.0] - 2022.12.13
### Created
- Start up this project.
- Submit to AMO.

### Bugs
- Don't run on Firefox for Android.