// "matches": ["*://metruyenchu.com/*", "*://metruyencv.com/*"]

console.log(`metruyenchu_idle.js - ${document.readyState}\n`);

const elem = document.getElementById('article');
if (elem != null) {
  elem.style.display = 'block';
  //elem.style.flexWrap = '';
  console.log('metruyenchu_idle.js - #article style: ', elem.style, ` - ${document.readyState}`);
} else {
  console.log('metruyenchu_idle.js - #article style: ', elem, ` - ${document.readyState}`);
}
