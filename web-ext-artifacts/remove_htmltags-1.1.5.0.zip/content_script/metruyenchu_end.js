// "matches": ["*://metruyenchu.com/*", "*://metruyencv.com/*"]

console.log(`metruyenchu_end.js - ${document.readyState}\n`);
